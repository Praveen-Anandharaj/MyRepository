package com.cts.jspp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.jspp.model.jobs;
import com.cts.jspp.serviceimpl.jobServiceImp;

@Controller
public class applyController {
@Autowired
jobServiceImp jobService;
	
	@GetMapping("/apply-jobs")
	public String packages() {
		
		return "userViewjob";
		
	}
	  @GetMapping("/listuser")
	    public String showjobsList(Model model) {
	        List<jobs> jobs = jobService.getAlljobs();
	        model.addAttribute("jobs", jobs);
	        return "userViewjob";
	    }
	  @PostMapping("/filteruser")
	    public String filterjobs(Model model, @Param("keyword") String keyword) {
	        List<jobs> jobfilter = jobService.searchjobs(keyword);
	        model.addAttribute("jobsfilter", jobfilter);
	        model.addAttribute("keyword", keyword);
	        return "userViewjob";
	    }
	  
	  
	  
}
