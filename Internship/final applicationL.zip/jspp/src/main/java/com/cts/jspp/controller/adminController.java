package com.cts.jspp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.jspp.model.jobs;
import com.cts.jspp.service.jobService;

@Controller
public class adminController {
    @Autowired
    private jobService jobService;

    @GetMapping("/add")
    public String showAddjobsForm() {
        return "add-job";
    }

    @GetMapping("/edit/{id}")
    public String showEditjobsForm(@PathVariable("id") int id, Model model) {
        jobs jobs = jobService.getjobsById(id);
        model.addAttribute("jobs", jobs);
        return "edit-jobs";
    }

    @GetMapping("/list")
    public String showjobsList(Model model) {
        List<jobs> job = jobService.getAlljobs();
        model.addAttribute("jobs", job);
        return "view-jobs";
    }

    @PostMapping("/save")
    public String savejobs(@ModelAttribute("jobs") jobs job) {
        jobService.savejobs(job);
        return "redirect:/list";
    }

    @PostMapping("/update")
    public String updatejobs(@ModelAttribute("jobs") jobs job) {
        jobService.updatejobs(job);
        return "redirect:/list";
    }

    @PostMapping("/delete/{id}")
    public String deletejobs(@PathVariable("id") int id) {
       jobService.deletejobs(id);
        return "redirect:/list";
    }
    
  

    @PostMapping("/filter")
    public String filterjobs(Model model, @Param("keyword") String keyword) {
        List<jobs>jobsfilter = jobService.searchjobs(keyword);
        model.addAttribute("jobsfilter", jobsfilter);
        model.addAttribute("keyword", keyword);
        return "view-jobs";
    }
    @GetMapping("/admin-home")
	public String AdminHome() {
		return "adminPage";
	}
   
}
