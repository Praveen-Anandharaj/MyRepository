package com.cts.jspp.service;

import java.util.List;
import com.cts.jspp.model.User;

public interface LoginService {
	List<User> getAllUsers();
	
	void deleteUser(int userId);

	void saveUser(User user);

	String getDesignation(String username);

	boolean isUserAlreadyPresent(String username);

	void login(String username, String password);

	boolean isUserAlreadyPresent1(String username);
}
