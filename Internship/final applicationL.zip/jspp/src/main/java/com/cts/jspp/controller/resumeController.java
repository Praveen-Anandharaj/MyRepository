package com.cts.jspp.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.cts.jspp.model.resume;
import com.cts.jspp.service.resumeService;

@Controller
public class resumeController {
	private resumeService resumeService = null;

	@Autowired
	public void setResumeService(resumeService resumeService) {
		this.resumeService = resumeService;
	}

	@GetMapping("/apply")
	public String showapplyForm() {
		return "apply-jobs";
	}

	@PostMapping("/apply")
	public String submitapplyForm(@ModelAttribute("resume") resume resume) {
		resumeService.saveresume(resume);
		return "confirmation";
	}
	

	@GetMapping("/admin-view-apply")
	public String showAdminViewapplyPage(Model model) {
		List<resume> resumes = resumeService.getAllresumes();
		model.addAttribute("resumes", resumes);
		return "admin-view-apply";
	}
	 
}
