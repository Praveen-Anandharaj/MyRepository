package com.cts.jspp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.jspp.model.resume;


public interface resumeRepository extends JpaRepository<resume, Long> {
}
