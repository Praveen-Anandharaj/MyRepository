package com.cts.jspp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class jobs {
    
    @Id
    private int job_id;
    
    @Column
    private String job_Name;
    
    @Column
    private String description;
    
    @Column
    private String qualification;
    
    @Column
    private float experience;
    
    @Column
    private String location;
    @Column
    private String skills_required;
    public jobs(int job_id, String job_Name, String description, String qualification, float experience, String location, String skills_required) {
        this.job_id = job_id;
        this.job_Name = job_Name;
        this.description = description;
        this.qualification = qualification;
        this.experience = experience;
        this.location = location;
        this.skills_required = skills_required;
    }
    
    // getters and setters
    
    public jobs() {}
    
    public int getJob_id() {
        return job_id;
    }

    public void setJob_id(int job_id) {
        this.job_id = job_id;
    }

    public String getJob_Name() {
        return job_Name;
    }

    public void setJob_Name(String job_Name) {
        this.job_Name = job_Name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public float getExperience() {
        return experience;
    }

    public void setExperience(float experience) {
        this.experience = experience;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSkills_required() {
        return skills_required;
    }

    public void setSkills_required(String skills_required) {
        this.skills_required = skills_required;
    }

    

	public jobs orElse(Object object) {
		return null;
	}
}
