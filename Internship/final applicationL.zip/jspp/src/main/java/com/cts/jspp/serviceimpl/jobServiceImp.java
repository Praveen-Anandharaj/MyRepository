package com.cts.jspp.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.jspp.model.jobs;
import com.cts.jspp.repository.jobRepo;
import com.cts.jspp.service.jobService;

@Service
public class jobServiceImp implements jobService {

    @Autowired
    private jobRepo jobRepository;

    @Override
    public jobs getjobsById(int id) {
        return jobRepository.findById(id).orElse(null);
    }

    @Override
    public void savejobs(jobs jobs) {
        jobRepository.save(jobs);
    }

    @Override
    public void updatejobs(jobs job) {
       jobRepository.save(job);
    }

    @Override
    public void deletejobs(int id) {
        jobRepository.deleteById(id);
    }

    @Override
    public List<jobs> getAlljobs() {
        return jobRepository.findAll();
    }

    @Override
    public List<jobs> searchjobs(String keyword) {
        if (keyword != null) {
            return jobRepository.search(keyword);
        }
        return jobRepository.findAll();
    }

    @Override
    public void updatejob(int job_id, String job_Name, String description, String qualification, float experience,
            String location, String skills_required)  {
        jobs jobToUpdate = jobRepository.findById(job_id).orElse(null);
        if (jobToUpdate != null) {
            jobToUpdate.setJob_Name(job_Name);
            jobToUpdate.setDescription(description);
            jobToUpdate.setQualification(qualification);
            jobToUpdate.setExperience(experience);
            jobToUpdate.setLocation(location);
            jobToUpdate.setSkills_required(skills_required);
            jobRepository.save(jobToUpdate);
        }
    }
    
    @Override
    public List<jobs> listAll(String keyword) {
        if (keyword != null) {
            return jobRepository.search(keyword.toLowerCase());
        }
        return jobRepository.findAll();
    }


}
