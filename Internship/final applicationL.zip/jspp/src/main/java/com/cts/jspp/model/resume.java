package com.cts.jspp.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "resume")
public class resume {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    
    private String firstName;

    
    private String lastName;

    
    private String email;

    
    private String contact;

    
    private String dob;

    
    private String gender;

    
    private String address;

    
    private String pincode;

    
    private String tenthPercentage;

    
    private String twelthPercentage;

    
    private float experienceLevel;

    
    private String highestQualification;

    
    private String highQualYear;
    
    
    private String highQualper;

    public resume() {
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getTenthPercentage() {
		return tenthPercentage;
	}

	public void setTenthPercentage(String tenthPercentage) {
		this.tenthPercentage = tenthPercentage;
	}

	public String getTwelthPercentage() {
		return twelthPercentage;
	}

	public void setTwelthPercentage(String twelthPercentage) {
		this.twelthPercentage = twelthPercentage;
	}

	public float getExperienceLevel() {
		return experienceLevel;
	}

	public void setExperienceLevel(float experienceLevel) {
		this.experienceLevel = experienceLevel;
	}

	public String getHighestQualification() {
		return highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	public String getHighQualYear() {
		return highQualYear;
	}

	public void setHighQualYear(String highQualYear) {
		this.highQualYear = highQualYear;
	}

	public String getHighQualper() {
		return highQualper;
	}

	public void setHighQualper(String highQualper) {
		this.highQualper = highQualper;
	}

	public resume(Long id, String firstName, String lastName, String email, String contact, String dob, String gender,
			String address, String pincode, String tenthPercentage, String twelthPercentage, float experienceLevel,
			String highestQualification, String highQualYear, String highQualper) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contact = contact;
		this.dob = dob;
		this.gender = gender;
		this.address = address;
		this.pincode = pincode;
		this.tenthPercentage = tenthPercentage;
		this.twelthPercentage = twelthPercentage;
		this.experienceLevel = experienceLevel;
		this.highestQualification = highestQualification;
		this.highQualYear = highQualYear;
		this.highQualper = highQualper;
	}

	@Override
	public String toString() {
		return "resume [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", contact=" + contact + ", dob=" + dob + ", gender=" + gender + ", address=" + address + ", pincode="
				+ pincode + ", tenthPercentage=" + tenthPercentage + ", twelthPercentage=" + twelthPercentage
				+ ", experienceLevel=" + experienceLevel + ", highestQualification=" + highestQualification
				+ ", highQualYear=" + highQualYear + ", highQualper=" + highQualper + "]";
	}

}