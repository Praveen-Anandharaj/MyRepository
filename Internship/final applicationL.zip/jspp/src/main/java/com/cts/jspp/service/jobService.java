package com.cts.jspp.service;

import java.util.List;

import com.cts.jspp.model.jobs;



public interface jobService {
	public List<jobs> listAll(String keyword);
    public void updatejob(int job_id, String job_Name, String description,String qualification, float experience,
            String location, String skills_required);
    public jobs getjobsById(int id);
    public void savejobs(jobs jobs);
    public void updatejobs(jobs jobs);
    public void deletejobs(int id);
    public List<jobs> getAlljobs();
    public List<jobs> searchjobs(String keyword);}
