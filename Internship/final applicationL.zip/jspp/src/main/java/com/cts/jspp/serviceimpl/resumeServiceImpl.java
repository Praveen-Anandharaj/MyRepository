package com.cts.jspp.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.jspp.model.resume;
import com.cts.jspp.repository.resumeRepository;
import com.cts.jspp.service.resumeService;

import java.util.List;

@Service
public class resumeServiceImpl implements resumeService {

	@Autowired
	private final resumeRepository resumeRepository;

	public resumeServiceImpl(resumeRepository resumeRepository) {
		this.resumeRepository = resumeRepository;
	}

	@Override
	public resume saveresume(resume resume) {
		return resumeRepository.save(resume);
	}

	@Override
	public List<resume> getAllresumes() {
		return resumeRepository.findAll();
	


    }
}
