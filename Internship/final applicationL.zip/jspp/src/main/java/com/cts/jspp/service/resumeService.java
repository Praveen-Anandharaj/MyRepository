package com.cts.jspp.service;

import java.util.List;

import com.cts.jspp.model.resume;

public interface resumeService {
	resume saveresume(resume resume);

	List<resume> getAllresumes();
}
