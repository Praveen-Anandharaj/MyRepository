  package com.cts.jspp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.jspp.model.User;

public interface UserLoginRepo extends JpaRepository<User, Integer> {
	public User findByUsername(String username);

	public Object existsByUsername(String username);
}
