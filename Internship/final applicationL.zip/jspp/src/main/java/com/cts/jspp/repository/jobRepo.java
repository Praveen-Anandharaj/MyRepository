package com.cts.jspp.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.jspp.model.jobs;



public interface jobRepo extends JpaRepository<jobs, Integer> {
	jobs findById(int id);
    void deleteById(int id);
    @Query("SELECT s FROM jobs s WHERE LOWER(CONCAT(s.job_id, ' ', s.job_Name, ' ', s.experience, ' ', s.location)) LIKE %:keyword%")
    public List<jobs> search(@Param("keyword")String keyword);
}
