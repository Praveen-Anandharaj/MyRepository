package com.cts.jspp.serviceimpl.java;



import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.jspp.model.jobs;
import com.cts.jspp.repository.jobRepo;
import com.cts.jspp.serviceimpl.jobServiceImp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class jobServiceImpTest {

    @Mock
    private jobRepo jobRepository;

    @InjectMocks
    private jobServiceImp jobService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void testGetjobsById_ExistingId_Returnsjobs() {
        // Arrange
        int jobId = 1;
        jobs expectedjobs = new jobs();
        // Set jobs properties if necessary

        // Mock the jobRepository.findById() method
        when(jobRepository.findById(jobId)).thenReturn(expectedjobs);

       
    }



  

    @Test
    void testSavejobs_Validjobs_CallsjobRepositorySaveMethod() {
        jobs jobs = new jobs();
       
        jobService.savejobs(jobs);

        // Assert: Verify that the jobRepository.save() method was called
        verify(jobRepository, times(1)).save(jobs);
    }

    @Test
    void testUpdatejobs_Validjobs_CallsjobRepositorySaveMethod() {
        // Arrange
        jobs job = new jobs();
        // Set job properties if necessary

        // Act
        jobService.updatejobs(job);

        // Assert: Verify that the jobRepository.save() method was called
        verify(jobRepository, times(1)).save(job);
    }

    @Test
    void testDeletejobs_ValidId_CallsjobRepositoryDeleteByIdMethod() {
        // Arrange
        int jobId = 1;

        // Act
        jobService.deletejobs(jobId);

        // Assert: Verify that the jobRepository.deleteById() method was called
        verify(jobRepository, times(1)).deleteById(jobId);
    }

    @Test
    void testGetAlljobs_ReturnsListOfjobs() {
        // Arrange
        List<jobs> expectedjobs = List.of(new jobs(), new jobs()); // Sample list of jobs

        when(jobRepository.findAll()).thenReturn(expectedjobs);

        // Act
        List<jobs> actualjobs = jobService.getAlljobs();

        // Assert
        assertEquals(expectedjobs, actualjobs);
    }

    @Test
    void testSearchjobs_WithKeyword_ReturnsListOfjobs() {
        // Arrange
        String keyword = "developer";
        List<jobs> expectedjobs = List.of(new jobs(), new jobs()); // Sample list of jobs

        when(jobRepository.search(keyword)).thenReturn(expectedjobs);

        // Act
        List<jobs> actualjobs = jobService.searchjobs(keyword);

        // Assert
        assertEquals(expectedjobs, actualjobs);
    }

    @Test
    void testSearchjobs_NullKeyword_ReturnsListOfjobs() {
        // Arrange
        String keyword = null;
        List<jobs> expectedjobs = List.of(new jobs(), new jobs()); // Sample list of jobs

        when(jobRepository.findAll()).thenReturn(expectedjobs);

        // Act
        List<jobs> actualjobs = jobService.searchjobs(keyword);

        // Assert
        assertEquals(expectedjobs, actualjobs);
    }

    

  

     
    @Test
    void testListAll_WithKeyword_ReturnsListOfjobs() {
        // Arrange
        String keyword = "developer";
        List<jobs> expectedjobs = List.of(new jobs(), new jobs()); // Sample list of jobs

        when(jobRepository.search(keyword.toLowerCase())).thenReturn(expectedjobs);

        // Act
        List<jobs> actualjobs = jobService.listAll(keyword);

        // Assert
        assertEquals(expectedjobs, actualjobs);
    }

    @Test
    void testListAll_NullKeyword_ReturnsListOfjobs() {
        // Arrange
        String keyword = null;
        List<jobs> expectedjobs = List.of(new jobs(), new jobs()); // Sample list of jobs

        when(jobRepository.findAll()).thenReturn(expectedjobs);

        // Act
        List<jobs> actualjobs = jobService.listAll(keyword);

        // Assert
        assertEquals(expectedjobs, actualjobs);
    }
}
