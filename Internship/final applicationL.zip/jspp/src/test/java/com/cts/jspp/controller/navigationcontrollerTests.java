package com.cts.jspp.controller;

import org.junit.jupiter.api.Test;
import org.springframework.ui.Model;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class NavigationControllerTest {

    @Test
    void testAbout() {
        // Create an instance of the NavigationController
        NavigationController navigationController = new NavigationController();

        // Invoke the about method
        String viewName = navigationController.about();

        // Verify the view name
        assertEquals("about", viewName);
    }

    @Test
    void testContact() {
        // Create an instance of the NavigationController
        NavigationController navigationController = new NavigationController();

        // Invoke the contact method
        String viewName = navigationController.contact();

        // Verify the view name
        assertEquals("contact", viewName);
    }

    @Test
    void testHome() {
        // Create an instance of the NavigationController
        NavigationController navigationController = new NavigationController();

        // Invoke the home method
        String viewName = navigationController.home();

        // Verify the view name
        assertEquals("welcome", viewName);
    }

    // Example test for a method that interacts with the Model object
    @Test
    void testAboutWithModel() {
        // Create an instance of the NavigationController
        NavigationController navigationController = new NavigationController();

        // Create a mock Model object
        Model model = mock(Model.class);

        // Invoke the about method
        String viewName = navigationController.about();

        // Verify the view name
        assertEquals("about", viewName);

        // Verify that the Model object was not used
        verifyNoInteractions(model);
    }

    // Add more test methods for other controller methods as needed
}

