package com.cts.jspp.serviceimpl.java;



import com.cts.jspp.model.resume;
import com.cts.jspp.repository.resumeRepository;
import com.cts.jspp.serviceimpl.resumeServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class resumeServiceImplTest {
    private resumeServiceImpl resumeService;
    private resumeRepository resumeRepository;

    @BeforeEach
    void setUp() {
        resumeRepository = mock(resumeRepository.class);
        resumeService = new resumeServiceImpl(resumeRepository);
    }

    @Test
    void testSaveresume_Validresume_ReturnsSavedresume() {
        // Arrange
        resume resume = new resume();
        // Set resume properties if necessary

        // Mock the resumeRepository.save() method
        when(resumeRepository.save(resume)).thenReturn(resume);

        // Act
        resume savedresume = resumeService.saveresume(resume);

        // Assert
        assertEquals(resume, savedresume);
    }

    @Test
    void testGetAllresumes_ReturnsListOfresumes() {
        // Arrange
        List<resume> expectedresumes = new ArrayList<>();
       
        when(resumeRepository.findAll()).thenReturn(expectedresumes);

        // Act
        List<resume> actualresumes = resumeService.getAllresumes();

        // Assert
        assertEquals(expectedresumes, actualresumes);
    }
}

