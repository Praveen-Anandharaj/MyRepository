package com.cts.jspp.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTest {

    @Test
    void testToString() {
        // Create a User instance with test data
        User user = new User();
        user.setUserId(1);
        user.setDesignation("Admin");
        user.setFname("John");
        user.setLname("Doe");
        user.setPhone("1234567890");
        user.setEmail("john.doe@example.com");
        user.setUsername("johndoe");
        user.setPassword("password");

        // Invoke the toString method
        String userString = user.toString();

        // Verify the string representation of the user
        String expectedString = "User [userId=1, designation=Admin, fname=John, lname=Doe, phone=1234567890, email=john.doe@example.com, username=johndoe, password=password]";
        assertEquals(expectedString, userString);
    }

    // Add more test methods for other functionality of the User class as needed
}

