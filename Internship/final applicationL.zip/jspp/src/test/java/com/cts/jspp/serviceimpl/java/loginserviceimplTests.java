package com.cts.jspp.serviceimpl.java;



import com.cts.jspp.Exception.*;
import com.cts.jspp.model.User;
import com.cts.jspp.repository.UserLoginRepo;
import com.cts.jspp.serviceimpl.LoginServiceImpl;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class LoginServiceImplTest {

	@Mock
	private UserLoginRepo userRepository;

	@InjectMocks
	private LoginServiceImpl loginService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testLogin_ValidCredentials() {
		String username = "john";
		String password = "password";
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);

		Mockito.when(userRepository.findByUsername(username)).thenReturn(user);

		Assertions.assertDoesNotThrow(() -> loginService.login(username, password));
	}

	@Test
	void testLogin_InvalidCredentials() {
		String username = "john";
		String password = "incorrect_password";
		User user = new User();
		user.setUsername(username);
		user.setPassword("password");

		Mockito.when(userRepository.findByUsername(username)).thenReturn(user);

		Assertions.assertThrows(InvalidCredentialsException.class, () -> loginService.login(username, password));
	}

	@Test
	void testLogin_UserDoesNotExist() {
		String username = "john";
		String password = "password";

		Mockito.when(userRepository.findByUsername(username)).thenReturn(null);

		Assertions.assertThrows(UserDoesNotExistException.class, () -> loginService.login(username, password));
	}

}
