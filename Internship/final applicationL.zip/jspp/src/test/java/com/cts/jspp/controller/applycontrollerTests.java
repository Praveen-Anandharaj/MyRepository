package com.cts.jspp.controller;



import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.jspp.model.jobs;
import com.cts.jspp.serviceimpl.jobServiceImp;

class applyControllerTest {

    private MockMvc mockMvc;

    @Mock
    private jobServiceImp jobService;

    @InjectMocks
    private applyController applyController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(applyController).build();
    }

    @Test
    void testShowJobsList() throws Exception {
        List<jobs> jobsList = new ArrayList<>();
        when(jobService.getAlljobs()).thenReturn(jobsList);

        mockMvc.perform(get("/listuser"))
                .andExpect(status().isOk())
                .andExpect(view().name("userViewjob"))
                .andExpect(model().attribute("jobs", jobsList));
    }

    @Test
    void testFilterJobs() throws Exception {
        String keyword = "example";
        List<jobs> filteredJobsList = new ArrayList<>();
        when(jobService.searchjobs(keyword)).thenReturn(filteredJobsList);

        mockMvc.perform(post("/filteruser")
                .param("keyword", keyword))
                .andExpect(status().isOk())
                .andExpect(view().name("userViewjob"))
                .andExpect(model().attribute("jobsfilter", filteredJobsList))
                .andExpect(model().attribute("keyword", keyword));
    }

   

   


}
