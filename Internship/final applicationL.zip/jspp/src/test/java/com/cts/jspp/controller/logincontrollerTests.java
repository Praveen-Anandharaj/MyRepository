package com.cts.jspp.controller;




import com.cts.jspp.Exception.InvalidCredentialsException;
import com.cts.jspp.Exception.UserDoesNotExistException;
import com.cts.jspp.service.LoginService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;

class LoginControllerTest {

	@Mock
	private LoginService loginService;

	@Mock
	private Model model;

	@InjectMocks
	private LoginController loginController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	

	@Test
	void testLogin_ValidCredentials_OtherDesignation() {
		String username = "john";
		String password = "password";
		String designation = "Employee";

		Mockito.when(loginService.getDesignation(username)).thenReturn(designation);

		String result = loginController.login(username, password, model);

		Assertions.assertEquals("welcome", result);
		Mockito.verify(model).addAttribute("designation", designation);
	}

	@Test
	void testLogin_InvalidCredentials() {
		String username = "john";
		String password = "incorrect_password";

		Mockito.doThrow(InvalidCredentialsException.class).when(loginService).login(Mockito.eq(username),
				Mockito.eq(password));

		String result = loginController.login(username, password, model);

		Assertions.assertEquals("UserLogin", result);
		Mockito.verify(model).addAttribute(Mockito.eq("error"), Mockito.any());
	}

	@Test
	void testLogin_UserDoesNotExist() {
		String username = "john";
		String password = "password";

		Mockito.doThrow(UserDoesNotExistException.class).when(loginService).login(Mockito.eq(username),
				Mockito.eq(password));

		String result = loginController.login(username, password, model);

		Assertions.assertEquals("UserLogin", result);
		Mockito.verify(model).addAttribute(Mockito.eq("error"), Mockito.isNull());
	}

	// Write similar tests for other methods in LoginController

}

