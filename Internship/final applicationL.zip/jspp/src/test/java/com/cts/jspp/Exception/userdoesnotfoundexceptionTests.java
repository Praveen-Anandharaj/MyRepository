package com.cts.jspp.Exception;



import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class UserDoesNotExistExceptionTest {

	@Test
	void testConstructor_WithMessage_Success() {
		String errorMessage = "User does not exist";
		UserDoesNotExistException exception = new UserDoesNotExistException(errorMessage);

		Assertions.assertEquals(errorMessage, exception.getMessage());
	}
}
