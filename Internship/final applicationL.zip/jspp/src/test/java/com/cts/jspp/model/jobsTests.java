package com.cts.jspp.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class JobsTest {

    @Test
    void testGetterAndSetterMethods() {
        // Create a jobs instance with test data
        jobs job = new jobs();
        job.setJob_id(1);
        job.setJob_Name("Software Engineer");
        job.setDescription("Develop software applications");
        job.setQualification("Bachelor's degree in Computer Science");
        job.setExperience(2.5f);
        job.setLocation("New York");
        job.setSkills_required("Java, SQL, Spring");

        // Verify the values using the getter methods
        assertEquals(1, job.getJob_id());
        assertEquals("Software Engineer", job.getJob_Name());
        assertEquals("Develop software applications", job.getDescription());
        assertEquals("Bachelor's degree in Computer Science", job.getQualification());
        assertEquals(2.5f, job.getExperience());
        assertEquals("New York", job.getLocation());
        assertEquals("Java, SQL, Spring", job.getSkills_required());
    }

    // Add more test methods for other functionality of the jobs class as needed
}
