package com.cts.jspp.controller;

import static org.mockito.Mockito.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.jspp.model.jobs;
import com.cts.jspp.service.jobService;

class adminControllerTest {

    private MockMvc mockMvc;

    @Mock
    private jobService jobService;

    @InjectMocks
    private adminController adminController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
    }

    @Test
    void testShowAddjobsForm() throws Exception {
        mockMvc.perform(get("/add"))
                .andExpect(status().isOk())
                .andExpect(view().name("add-job"));
    }

    @Test
    void testShowEditjobsForm() throws Exception {
        int jobId = 1;
        jobs job = new jobs();
        when(jobService.getjobsById(jobId)).thenReturn(job);

        mockMvc.perform(get("/edit/{id}", jobId))
                .andExpect(status().isOk())
                .andExpect(view().name("edit-jobs"))
                .andExpect(model().attribute("jobs", job));
    }

    @Test
    void testShowjobsList() throws Exception {
        List<jobs> jobsList = new ArrayList<>();
        when(jobService.getAlljobs()).thenReturn(jobsList);

        mockMvc.perform(get("/list"))
                .andExpect(status().isOk())
                .andExpect(view().name("view-jobs"))
                .andExpect(model().attribute("jobs", jobsList));
    }

    @Test
    void testSavejobs() throws Exception {
        jobs job = new jobs();

        mockMvc.perform(post("/save")
                .flashAttr("jobs", job))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/list"));

        verify(jobService, times(1)).savejobs(job);
    }

    @Test
    void testUpdatejobs() throws Exception {
        jobs job = new jobs();

        mockMvc.perform(post("/update")
                .flashAttr("jobs", job))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/list"));

        verify(jobService, times(1)).updatejobs(job);
    }

    @Test
    void testDeletejobs() throws Exception {
        int jobId = 1;

        mockMvc.perform(post("/delete/{id}", jobId))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/list"));

        verify(jobService, times(1)).deletejobs(jobId);
    }

    @Test
    void testFilterjobs() throws Exception {
        String keyword = "example";
        List<jobs> filteredJobsList = new ArrayList<>();
        when(jobService.searchjobs(keyword)).thenReturn(filteredJobsList);

        mockMvc.perform(post("/filter")
                .param("keyword", keyword))
                .andExpect(status().isOk())
                .andExpect(view().name("view-jobs"))
                .andExpect(model().attribute("jobsfilter", filteredJobsList))
                .andExpect(model().attribute("keyword", keyword));
    }
}
