package com.cts.jspp.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ResumeTest {
    private resume resume;

    @BeforeEach
    void setUp() {
        // Create a new instance of the Resume class before each test
        resume = new resume();
    }

    @Test
    void testGettersAndSetters() {
        // Set values using setters
        resume.setId(1L);
        resume.setFirstName("John");
        resume.setLastName("Doe");
        resume.setEmail("john.doe@example.com");
        // ... set other properties using setters

        // Verify values using getters
        assertEquals(1L, resume.getId());
        assertEquals("John", resume.getFirstName());
        assertEquals("Doe", resume.getLastName());
        assertEquals("john.doe@example.com", resume.getEmail());
        // ... verify other properties using getters
    }

    @Test
    void testToString() {
        // Set values using setters
        resume.setId(1L);
        resume.setFirstName("John");
        resume.setLastName("Doe");
        resume.setEmail("john.doe@example.com");
        resume.setContact("1234567890");
        resume.setDob("1990-01-01");
        resume.setGender("Male");
        resume.setAddress("123 Main St");
        resume.setPincode("12345");
        resume.setTenthPercentage("95%");
        resume.setTwelthPercentage("90%");
        resume.setExperienceLevel(3.5f);
        resume.setHighestQualification("Bachelor's Degree");
        resume.setHighQualYear("2015");
        resume.setHighQualper("80%");
        // ... set other properties using setters

        // Verify the string representation
        String expectedString = "resume [id=1, firstName=John, lastName=Doe, email=john.doe@example.com, contact=1234567890, dob=1990-01-01, gender=Male, address=123 Main St, pincode=12345, tenthPercentage=95%, twelthPercentage=90%, experienceLevel=3.5, highestQualification=Bachelor's Degree, highQualYear=2015, highQualper=80%]";
        assertEquals(expectedString, resume.toString());
    }
}
