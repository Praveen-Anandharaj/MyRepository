package com.cts.jspp.Exception;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class InvalidCredentialsExceptionTest {

	@Test
	void testConstructor_WithMessage_Success() {
		String errorMessage = "Invalid credentials";
		InvalidCredentialsException exception = new InvalidCredentialsException(errorMessage);

		Assertions.assertEquals(errorMessage, exception.getMessage());
	}
}

